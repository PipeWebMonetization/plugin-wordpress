<?php
/**
 * Intentionally empty file.
 *
 * It exists to stop directory listings on poorly configured servers.
 *
 * @package     Pipe_Web_Monetization
 * @subpackage  Pipe_Web_Monetization/includes
 */
